export interface TestResult {
  id: string;
  date: string;
  arv: string;
  cd4: number;
  viralLoad: number;
}