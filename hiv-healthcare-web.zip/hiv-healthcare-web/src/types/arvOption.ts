export interface ARVOption {
  id: string;
  name: string;
  suitableFor: string;
}