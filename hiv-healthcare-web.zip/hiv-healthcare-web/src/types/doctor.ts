// src/types/doctor.ts
export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  degree: string;
  schedule: string;
}
