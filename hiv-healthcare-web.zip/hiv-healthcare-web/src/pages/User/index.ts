export { default as Dashboard } from './Dashboard';
export { default as Profile } from './Profile';
export { default as AppointmentsUser } from './AppointmentsUser';
export { default as MedicalRecords } from './MedicalRecords';
export { default as Notifications } from './Notifications';
export { default as HIVHistory } from './HIVHistory'; 